EMAIL_USE_TLS = False
EMAIL_USE_SSL = True
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'officialdavidazowenu1@gmail.com'
EMAIL_HOST_PASSWORD = 'nrkvgylzmeoxldkr'
EMAIL_PORT = 465