
$('.owl-carousel').owlCarousel({
    loop:true,
    autoplay: true,
    autoplayHoverPause: true,
    autoplayTimeout: 1000,
    margin:5,
    responsiveClass:true,
    responsive:{
        0:{
            items:2.5,
        },
        600:{
            items:4,
        },
        1000:{
            items:4.5,
        }
    }
})




